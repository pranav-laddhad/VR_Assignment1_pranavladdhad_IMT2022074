import cv2
import matplotlib.pyplot as plt

def detect_and_display_keypoints(image_paths):
    """Detect and display keypoints for each image using SIFT."""
    sift = cv2.SIFT_create()

    for img_path in image_paths:
        image = cv2.imread(img_path)
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

        keypoints, _ = sift.detectAndCompute(gray, None)

        # Draw only small red dots at keypoints
        img_with_keypoints = image.copy()
        for kp in keypoints:
            x, y = int(kp.pt[0]), int(kp.pt[1])
            cv2.circle(img_with_keypoints, (x, y), 2, (0, 0, 255), -1)  # Red dot

        # Convert BGR to RGB for Matplotlib display
        img_rgb = cv2.cvtColor(img_with_keypoints, cv2.COLOR_BGR2RGB)

        plt.figure(figsize=(6, 6))
        plt.imshow(img_rgb)
        plt.axis("off")
        # plt.title(f"Keypoints in {img_path.split('/')[-1]}")
        plt.show()

def stitch_images(image_paths):
    """Stitch multiple images using OpenCV's built-in Stitcher."""
    images = [cv2.imread(img) for img in image_paths]

    if len(images) < 2:
        print("Need at least two images!")
        return

    stitcher = cv2.Stitcher_create()
    status, panorama = stitcher.stitch(images)

    if status == cv2.Stitcher_OK:
        cv2.imwrite("panorama.png", panorama)

        panorama_rgb = cv2.cvtColor(panorama, cv2.COLOR_BGR2RGB)
        plt.figure(figsize=(10, 5))
        plt.imshow(panorama_rgb)
        plt.axis("off")
        plt.title("Stitched Panorama")
        plt.show()
    else:
        print("Stitching failed!")

def main():
    image_paths = [
        'unstitched_images/left.png',
        'unstitched_images/middle.png',
        'unstitched_images/right.png'
    ]

    print("🔍 Detecting and displaying keypoints...")
    detect_and_display_keypoints(image_paths)

    print("🖼️ Stitching images into a panorama...")
    stitch_images(image_paths)

if __name__ == "__main__":
    main()

