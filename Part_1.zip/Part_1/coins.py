import cv2
import numpy as np
import matplotlib.pyplot as plt
import os

# Load image
image = cv2.imread('coins3.png')

if image is None:
    print("Error: Could not load image. Check file path!")
    exit()

# Convert to grayscale
gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

# Apply Gaussian Blur
blur = cv2.GaussianBlur(gray, (5, 5), 0)

# Create output directory
output_dir = "output_images"
os.makedirs(output_dir, exist_ok=True)

# Apply binary thresholding
_, binary = cv2.threshold(blur, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)

# Morphological closing to remove small holes
kernel = np.ones((3, 3), np.uint8)
binary_cleaned = cv2.morphologyEx(binary, cv2.MORPH_CLOSE, kernel, iterations=2)

# Edge detection using Canny
edges = cv2.Canny(binary_cleaned, 120, 250)
cv2.imwrite(os.path.join(output_dir, "edge_detection_output.jpg"), edges)

# Segmentation using contours
contours, _ = cv2.findContours(binary_cleaned, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
segmented = np.zeros_like(gray)
cv2.drawContours(segmented, contours, -1, 255, thickness=cv2.FILLED)
cv2.imwrite(os.path.join(output_dir, "segmentation_output.jpg"), segmented)

# Counting the coins using filtered contours
min_contour_area = 500  # Adjust this value if necessary
filtered_cnt = [c for c in contours if cv2.contourArea(c) > min_contour_area]

# Draw contours on the original image
output = image.copy()
cv2.drawContours(output, filtered_cnt, -1, (0, 255, 0), thickness=2)

# Convert BGR to RGB for proper display
rgb = cv2.cvtColor(output, cv2.COLOR_BGR2RGB)

# Add total count of coins
num_coins = len(filtered_cnt)
cv2.putText(rgb, f'Total Coins: {num_coins}', (50, 50), cv2.FONT_HERSHEY_SIMPLEX, 
            1, (255, 0, 0), 2, cv2.LINE_AA)
cv2.imwrite(os.path.join(output_dir, "count_coins_output.jpg"), rgb)

# Create subplots to visualize all processing steps
fig, axs = plt.subplots(2, 3, figsize=(15, 10))

# Plot each processing step
axs[0, 0].imshow(gray, cmap='gray')
axs[0, 0].set_title("Grayscale Image")

axs[0, 1].imshow(blur, cmap='gray')
axs[0, 1].set_title("Blurred Image")

axs[0, 2].imshow(binary_cleaned, cmap='gray')
axs[0, 2].set_title("Binary Thresholding (Cleaned)")

axs[1, 0].imshow(edges, cmap='gray')
axs[1, 0].set_title("Edge Detection (Canny)")

axs[1, 1].imshow(segmented, cmap='gray')
axs[1, 1].set_title("Segmented Coins")

axs[1, 2].imshow(rgb)
axs[1, 2].set_title(f"Final Count (Total Coins: {num_coins})")

for ax in axs.flat:
    ax.axis("off")

# Show the figure
plt.tight_layout()
plt.show()

print("Number of coins in the image:", num_coins)
